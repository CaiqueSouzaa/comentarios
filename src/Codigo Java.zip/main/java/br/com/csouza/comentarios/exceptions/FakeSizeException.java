package br.com.csouza.comentarios.exceptions;

public class FakeSizeException extends Exception {
	public FakeSizeException(String msg) {
		super(msg);
	}
}
