package br.com.csouza.comentarios.exceptions;

public class PostNotFoundException extends Exception {
	public PostNotFoundException(String msg) {
		super(msg);
	}
}
