package br.com.csouza.comentarios.exceptions;

public class UserInvalidException extends Exception {
	public UserInvalidException(String msg) {
		super(msg);
	}
}
