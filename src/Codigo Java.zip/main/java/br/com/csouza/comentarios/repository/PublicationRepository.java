package br.com.csouza.comentarios.repository;

import java.util.HashSet;

import br.com.csouza.comentarios.domain.Post;
import br.com.csouza.comentarios.domain.Publication;
import br.com.csouza.comentarios.domain.User;
import br.com.csouza.comentarios.interfaces.repository.IPostRepository;
import br.com.csouza.comentarios.interfaces.repository.IUserRepository;

public class PublicationRepository {
	private IUserRepository userRepository;
	private IPostRepository postRepository;
	
	public PublicationRepository(IUserRepository userRepository, IPostRepository postRepository) {
		this.userRepository = userRepository;
		this.postRepository = postRepository;
	}
	
	/**
	 * Método para realizar o registro de uma nova publicação.
	 * @param post Publicação a ser registrada.
	 * @param user Usuário que está criando a publicação.
	 * @return Publicação registrada.
	 */
	public Publication register(Post post, final User user) {
		if (user.getId() == null) {
			throw new RuntimeException("Usuário não localizado ou não registrado.");
		}

		// Verificando se o usuário está registrado.
		try {
			this.userRepository.getById(user.getId());
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

		// Atribuindo o usuário ao post.
		post.setUser(user);
		// Registrando o post.
		post = this.postRepository.register(post);

		final Publication publication = new Publication();
		publication.setUser(user);
		publication.setPost(post);
		publication.setComments(new HashSet<>());

		return publication;
	}
}
