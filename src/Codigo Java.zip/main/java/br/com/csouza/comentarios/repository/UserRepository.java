package br.com.csouza.comentarios.repository;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.csouza.comentarios.domain.User;
import br.com.csouza.comentarios.exceptions.UserNotFoundException;
import br.com.csouza.comentarios.interfaces.dao.IUserDAO;
import br.com.csouza.comentarios.interfaces.repository.IUserRepository;

public class UserRepository extends Repository<User, Long> implements IUserRepository {
	private final IUserDAO userDAO;
	
	public UserRepository(IUserDAO userDAO) {
		super(userDAO);
		this.userDAO = userDAO;
	}

	/**
	 * Método privado para verificar se um atributo pode ser nulo ou não.
	 * @param field - Nome do atributo.
	 * @param value - Valor do atributo
	 * @param nullable - Se o atributo pode ser nulo ou não.
	 */
	private void canNull(String field, Object value, boolean nullable) {
		if (nullable == false && value == null) {
			throw new RuntimeException("O campo [" + field + "] não pode estar vázio.");
		}
	}
	
	private void checkString(String field, String text, int size, boolean canNull, String regex) {
		this.canNull(field, text, canNull);

		if (regex != null) {
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(text);

			if (!matcher.matches()) {
				throw new RuntimeException("O valor [" + text + "] não é compativel com o campo [" + field + "].");
			}
		}

		if (text == null || text.length() < size) {
			throw new RuntimeException("O " + field + " de usuário deve ser maior ou igual a " + size + " caracteres.");
		}
	}
	
	@Override
	public User register(User user) {
		final String emailRegex = "^[a-zA-Z0-9.]+@[a-zA-Z0-9.]+\\.[a-zA-Z0-9.]+$";

		this.checkString("nome", user.getName(), 3, false ,null);
		this.checkString("sobrenome", user.getSurname(), 3, false ,null);
		this.checkString("login", user.getLogin(), 5, false ,null);
		this.checkString("endereço de e-mail", user.getEmail(), 5, false, emailRegex);
		this.canNull("aniversário", user.getBirthday(), false);
		
		return this.userDAO.create(user);
	}

	@Override
	public User getByLogin(String login) throws UserNotFoundException {
		return this.userDAO.findByLogin(login);
	}

	@Override
	public User getByEmail(String email) throws UserNotFoundException  {
		return this.userDAO.findByEmail(email);
	}
}
